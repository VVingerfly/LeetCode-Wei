#include <iostream>
#include <vector>
using namespace std;

void oneStep(vector<int> &ring)
{
	int head = ring.front();
	for (size_t i = 0; i < ring.size() - 1; i++)
	{
		int sum_i = ring.at(i) + ring.at(i + 1);
		ring.at(i) = sum_i % 100;
	}
	int sum_n = ring.back() + head;
	ring.back() = sum_n % 100;
}

void printRing(const vector<int> &ring)
{
	for (size_t i = 0; i < ring.size(); i++)
	{
		cout << ring.at(i);
		if (i != ring.size()-1)
		{
			cout << " ";
		}
	}
	cout << endl;
}

/*
int main()
{
	int n, k;
	cin >> n >> k;
	vector<int> magicRing;
	for (size_t i = 0; i < n; i++)
	{
		int num;
		cin >> num;
		magicRing.push_back(num);
	}
	for (size_t i = 0; i < k; i++)
	{
		oneStep(magicRing);
	}

	printRing(magicRing);
	return 0;
}

*/