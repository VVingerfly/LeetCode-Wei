#include <iostream>
#include <vector>
#include <string>
#include <map>
using namespace std;

int arrangementNum(vector<map<int, int>> &tasks)
{
	int num = 0;
	for (size_t i = 0; i < tasks.size(); i++)
	{
		num *= tasks.at(i).size();
	}
	return num;
}

void personId4Task(const vector<map<int, int>> &tasksTotal, vector<map<int, int>> &personsTotal)
{
	// store person id for each task
	for (size_t ti = 0; ti < 6; ti++)
	{
		map<int, int> task_i;
		for (size_t pi = 0; pi < tasksTotal.size(); pi++)
		{
			if (tasksTotal.at(pi).find(ti) != tasksTotal.at(pi).end())   // find
			{
				task_i.insert(make_pair(pi, ti));
			}
		}
		personsTotal.push_back(task_i);
	}
	
}

void uniqueTaskId4Person(vector<map<int, int>> &tasksTotal, vector<map<int, int>> &tasksUnique)
{
	// store task id that is a person's unique ability

}

void totalTaskId4Person(const vector<string> &tasks, vector<map<int, int>> &tasksMap)
{
	// store task id for each person
	for (size_t i = 0; i < tasks.size(); i++)
	{
		map<int, int> person_i;
		for (size_t j = 0; j < tasks.at(i).length(); j++)
		{
			int taskId = atoi((tasks.at(i).substr(j,1)).c_str());
			person_i.insert(make_pair(taskId, i));
		}
		tasksMap.push_back(person_i);
	}
}

void printTasks(const vector<string> &tasks)
{
	for (size_t i = 0; i < tasks.size(); i++)
	{
		cout << i << " -> " << tasks.at(i) << endl;
	}
}
int main()
{
	int n;
	cin >> n;
	vector<string> tasks;
	for (size_t i = 0; i < n; i++)
	{
		string str;
		cin >> str;
		tasks.push_back(str);
	}
	//printTasks(tasks);

	vector<map<int, int>> tasksTotal;
	totalTaskId4Person(tasks, tasksTotal);

	arrangementNum(tasksTotal);

	return 0;
}